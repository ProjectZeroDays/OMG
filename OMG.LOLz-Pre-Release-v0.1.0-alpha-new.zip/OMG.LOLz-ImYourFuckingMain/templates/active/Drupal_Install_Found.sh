AUTHOR='@xer0dayz'
VULN_NAME='Drupal Install Found'
URI='/install.php?profile=default'
METHOD='GET'
MATCH='Choose language | Drupal'
SEVERITY='P3 - MEDIUM'
CURL_OPTS="--user-agent '' -s -L --insecure"
SECONDARY_COMMANDS=''
GREP_OPTIONS='-i'