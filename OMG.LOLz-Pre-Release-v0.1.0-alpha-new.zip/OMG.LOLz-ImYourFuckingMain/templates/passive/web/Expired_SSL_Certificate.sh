AUTHOR='@xer0dayz'
VULN_NAME='Expired SSL Certificate'
FILENAME="$LOOT_DIR/web/curldebug-$TARGET-*.txt"
MATCH='certificate has expired'
SEVERITY='P3 - MEDIUM'
GREP_OPTIONS=''
SEARCH='positive'
SECONDARY_COMMANDS=''