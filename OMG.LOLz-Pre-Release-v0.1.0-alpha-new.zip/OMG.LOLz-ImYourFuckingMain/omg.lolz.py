#!/usr/bin/env python3

import os
import subprocess
import sys

def logo():
    print('''
    #!/bin/bash
    # + -- --=[OMG.LOLz - Ezra - Project Zero
    # + -- --=[https://github.com/ProjectZeroDays/OMG.LOLz/archive/refs/heads/ImYourFuckingMain.zip
    #
    ''')
    print('''
    #!/usr/bin/env python3

    import os
    import subprocess
    import sys

    def logo():
        print(r"""
        #!/usr/bin/env python3

        import os
        import subprocess
        import sys

        def logo():
            print(r"""
            $OKRED                                                  $RESET
            $OKRED    ___  __  __  ____      _     ___   __  ____   $RESET
            $OKRED   / _ \|  \/  |/ ___|    / /  / ,, | / / |__ /   $RESET
            $OKRED  | | | | |\/| | |  _    / /  / / / // /   / /    $RESET
            $OKRED  | |_| | |  | | |_| |  / /__/ /_/ // /__ / /__   $RESET
            $OKRED   \___/|_|  |_|\____| /____/\____//____//____/   $RESET
            $OKRED                                                  $RESET
            $OKRED                                                  $RESET
            $OKORANGE        OMG.LOLz by Ezra - Project Zero        $RESET
            $OKORANGE      https://github.com/ProjectZeroDays/      $RESET
            $OKRED                                                  $RESET
            $OKRED   New Functions for Wifite2, Hydra, & John The   $RESET
            $OKRED   Ripper have been added & can be called by      $RESET
            $OKRED   passing the perspective command line options.  $RESET
            $OKRED                                                  $RESET
            $OKRED   For Example:                                   $RESET
            $OKRED   -w for Wifite2, -h for Hydra, & -j for John.   $RESET
            $OKRED                                                  $RESET
            """)

    def check_update():
        if ENABLE_AUTO_UPDATES == "1":
            try:
                latest_ver = subprocess.check_output(['curl', '--connect-timeout', '5', '-s', 'https://api.github.com/repos/ProjectZeroDays/OMG.LOLz/tags'])
                latest_ver = latest_ver.decode().strip().split('"name":')[1].split(',')[0].strip('"')
                if latest_ver != VER:
                    print(f"$OKBLUE[$RESET${OKRED}i${RESET}$OKBLUE] OMG.LOLz v{latest_ver} is available to download... To update, type$OKRED \"omg.lolz -u\" $RESET")
            except:
                print("Error checking for updates.")
        else:
            print("Auto updates are disabled.")

    def update():
        logo()
        print("$OKBLUE[*]$RESET Checking for updates...$OKBLUE[$OKGREEN}OK${RESET}$OKBLUE]$RESET")
        try:
            latest_ver = subprocess.check_output(['curl', '--connect-timeout', '5', '-s', 'https://api.github.com/repos/ProjectZeroDays/OMG.LOLz/tags'])
            latest_ver = latest_ver.decode().strip().split('"name":')[1].split(',')[0].strip('"')
            if latest_ver != VER:
                print(f"$OKBLUE[$RESET${OKRED}i${RESET}$OKBLUE] OMG.LOLz {latest_ver} is available to download...Do you want to update? (y or n)$RESET")
                ans = input()
                if ans.lower() == "y":
                    if os.system('command -v git &> /dev/null') == 0:
                        os.system('rm -Rf /tmp/OMG.LOLz/ 2>/dev/null')
                        os.system('git clone https://github.com/ProjectZeroDays/OMG.LOLz /tmp/OMG.LOLz/')
                        os.chdir('/tmp/OMG.LOLz/')
                        os.system('chmod +rx install.sh')
                        os.system('bash install.sh')
                        os.system('rm -Rf /tmp/OMG.LOLz/ 2>/dev/null')
                        sys.exit()
                    else:
                        print("Error: Git is not installed. Please install Git to update OMG.LOLz.")
        except:
            print("Error checking for updates.")

    if os.getenv("UPDATE") == "1":
        update()
        sys.exit()

    def check_online():
        try:
            subprocess.check_output(['curl', '--connect-timeout', '3', '--insecure', '-s', 'https://sn1persecurity.com/community/updates.txt?$VER&mid=$(cat /etc/hostname)'])
            ONLINE = "1"
        except:
            ONLINE = "0"
            print("Error: Unable to check online status. Please verify your internet connection.")
        return ONLINE

    ONLINE = check_online()

    def launch_wifite2_attack():
        print("$OKBLUE[*]$RESET Launching wifite2 automated attack...")
        subprocess.run(['wifite2', '-a', '-i', 'wlan0', '--wps', '--pixie', '--kill-all'])

    def run_hydra():
        print("$OKBLUE[*]$RESET Running Hydra...")
        subprocess.run(['hydra', '-l', '/wordlists/usernames-full.txt', '-P', '/wordlists/web-brute-full.txt', 'target_ip', 'ssh', '-V'])

    def run_john():
        print("$OKBLUE[*]$RESET Running John the Ripper...")
        subprocess.run(['john', '--wordlist=/wordlists/web-brute-full.txt', 'hashfile'])

    def help():
        logo()
        print("""
        NORMAL MODE
        omg.lolz -t <TARGET>

        SPECIFY CUSTOM CONFIG FILE
        omg.lolz -c /full/path/to/omg.lolz.conf -t <TARGET> -m <MODE> -w <WORKSPACE>

        NORMAL MODE + OSINT + RECON
        omg.lolz -t <TARGET> -o -re

        STEALTH MODE + OSINT + RECON
        omg.lolz -t <TARGET> -m stealth -o -re

        DISCOVER MODE
        omg.lolz -t <CIDR> -m discover -w <WORSPACE_ALIAS>

        SCAN ONLY SPECIFIC PORT
        omg.lolz -t <TARGET> -m port -p <portnum>

        FULLPORTONLY SCAN MODE
        omg.lolz -t <TARGET> -fp

        WEB MODE - PORT 80 + 443 ONLY!
        omg.lolz -t <TARGET> -m web

        HTTP WEB PORT MODE
        omg.lolz -t <TARGET> -m webporthttp -p <port>

        HTTPS WEB PORT MODE
        omg.lolz -t <TARGET> -m webporthttps -p <port>

        HTTP WEBSCAN MODE
        omg.lolz -t <TARGET> -m webscan

        ENABLE BRUTEFORCE
        omg.lolz -t <TARGET> -b

        AIRSTRIKE MODE
        omg.lolz -f targets.txt -m airstrike

        NUKE MODE WITH TARGET LIST, BRUTEFORCE ENABLED, FULLPORTSCAN ENABLED, OSINT ENABLED, RECON ENABLED, WORKSPACE & LOOT ENABLED
        omg.lolz -f targets.txt -m nuke -w <WORKSPACE_ALIAS>

        MASS PORT SCAN MODE
        omg.lolz -f targets.txt -m massportscan -w <WORKSPACE_ALIAS>

        MASS WEB SCAN MODE
        omg.lolz -f targets.txt -m massweb -w <WORKSPACE_ALIAS>

        MASS WEBSCAN SCAN MODE
        omg.lolz -f targets.txt -m masswebscan -w <WORKSPACE_ALIAS>

        MASS VULN SCAN MODE
        omg.lolz -f targets.txt -m massvulnscan -w <WORKSPACE_ALIAS>

        PORT SCAN MODE
        omg.lolz -t <TARGET> -m port -p <PORT_NUM>

        LIST WORKSPACES
        omg.lolz --list

        DELETE WORKSPACE
        omg.lolz -w <WORKSPACE_ALIAS> -d

        DELETE HOST FROM WORKSPACE
        omg.lolz -w <WORKSPACE_ALIAS> -t <TARGET> -dh

        DELETE TASKS FROM WORKSPACE
        omg.lolz -w <WORKSPACE_ALIAS> -t <TARGET> -dt

        GET omg.lolz SCAN STATUS
        omg.lolz --status

        LOOT REIMPORT FUNCTION
        omg.lolz -w <WORKSPACE_ALIAS> --reimport

        LOOT REIMPORTALL FUNCTION
        omg.lolz -w <WORKSPACE_ALIAS> --reimportall

        LOOT REIMPORT FUNCTION
        omg.lolz -w <WORKSPACE_ALIAS> --reload

        LOOT EXPORT FUNCTION
        omg.lolz -w <WORKSPACE_ALIAS> --export

        SCHEDULED SCANS
        omg.lolz -w <WORKSPACE_ALIAS> -s daily|weekly|monthly

        USE A CUSTOM CONFIG
        omg.lolz -c /path/to/omg.lolz.conf -t <TARGET> -w <WORKSPACE_ALIAS>

        UPDATE omg.lolz
        omg.lolz -u|--update
        """)
        sys.exit()

    def main():
        if len(sys.argv) < 2:
            help()

        # Parse command-line arguments
        target = None
        mode = None
        port = None
        file = None
        workspace = None
        schedule_arg = None
        for i in range(1, len(sys.argv)):
            if sys.argv[i] == "-t":
                target = sys.argv[i+1]
            elif sys.argv[i] == "-m":
                mode = sys.argv[i+1]
            elif sys.argv[i] == "-p":
                port = sys.argv[i+1]
            elif sys.argv[i] == "-f":
                file = sys.argv[i+1]
            elif sys.argv[i] == "-w":
                workspace = sys.argv[i+1]
            elif sys.argv[i] == "-s":
                schedule_arg = sys.argv[i+1]

        # Execute commands based on the parsed arguments
        if mode == "wifite2":
            launch_wifite2_attack()
        elif mode == "hydra":
            run_hydra()
        elif mode == "john":
            run_john()
        elif mode == "help":
            help()
        else:
            print("Unknown mode:", mode)

if __name__ == "__main__":
    main()

 def omg_lolz_status():
    subprocess.run(['watch', '-n', '1', '-c', 'ps -ef | egrep "omg.lolz|slurp|hydra|ruby|python|dirsearch|amass|nmap|metasploit|curl|wget|nikto" && echo "NETWORK CONNECTIONS..." && netstat -an | egrep "TIME_WAIT|EST"'])

def run_command(command):
    try:
        subprocess.run(command, shell=True)
    except Exception as e:
        print(f"Error running command: {e}")

def run_nmap(target, port=None, options=None):
    if port:
        command = f"nmap -p{port} {target}"
    else:
        command = f"nmap {target}"
    if options:
        command += f" {options}"
    run_command(command)

def run_dirsearch(target, wordlist=None, extensions=None, threads=None):
    command = f"dirsearch -u {target}"
    if wordlist:
        command += f" -w {wordlist}"
    if extensions:
        command += f" -e {extensions}"
    if threads:
        command += f" -t {threads}"
    run_command(command)

def run_amass(mode, target):
    if mode == "enum":
        command = f"amass enum -d {target}"
    elif mode == "track":
        command = f"amass track -d {target}"
    elif mode == "viz":
        command = f"amass viz -d {target}"
    run_command(command)

def run_metasploit(module, target, options=None):
    command = f"msfconsole -q -x 'use {module}; set RHOSTS {target};"
    if options:
        for key, value in options.items():
            command += f" set {key} {value};"
    command += "run'"
    run_command(command)

def run_curl(url, output_file=None, headers=None, data=None, method=None):
    command = f"curl {url}"
    if output_file:
        command += f" -o {output_file}"
    if headers:
        for header in headers:
            command += f" -H '{header}'"
    if data:
        command += f" -d '{data}'"
    if method:
        command += f" -X {method}"
    run_command(command)

def run_wget(url, output_file=None, headers=None, data=None, method=None):
    command = f"wget {url}"
    if output_file:
        command += f" -O {output_file}"
    if headers:
        for header in headers:
            command += f" --header='{header}'"
    if data:
        command += f" --post-data='{data}'"
    if method:
        command += f" --method={method}"
    run_command(command)

def run_nikto(target, port=None):
    if port:
        command = f"nikto -h {target} -p {port}"
    else:
        command = f"nikto -h {target}"
    run_command(command)

def create_workspace(workspace_alias):
    workspace_dir = os.path.join(LOOT_DIR, workspace_alias)
    if not os.path.exists(workspace_dir):
        os.makedirs(workspace_dir)
        print(f"$OKBLUE[*]$RESET Created new workspace: {workspace_dir} $OKBLUE[$RESET${OKGREEN}OK${RESET}$OKBLUE]$RESET")
    else:
        print(f"$OKBLUE[*]$RESET Workspace already exists: {workspace_dir} $OKBLUE[$RESET${OKGREEN}OK${RESET}$OKBLUE]$RESET")

def delete_workspace(workspace_alias):
    workspace_dir = os.path.join(LOOT_DIR, workspace_alias)
    if os.path.exists(workspace_dir):
        try:
            shutil.rmtree(workspace_dir)
            print(f"$OKBLUE[*]$RESET Deleted workspace: {workspace_dir} $OKBLUE[$RESET${OKGREEN}OK${RESET}$OKBLUE]$RESET")
        except Exception as e:
            print(f"$OKBLUE[*]$RESET Error deleting workspace: {e} $OKBLUE[$RESET${OKRED}FAILED${RESET}$OKBLUE]$RESET")
    else:
        print(f"$OKBLUE[*]$RESET Workspace not found: {workspace_dir} $OKBLUE[$RESET${OKRED}FAILED${RESET}$OKBLUE]$RESET")

def delete_host_from_workspace(workspace_alias, target):
    workspace_dir = os.path.join(LOOT_DIR, workspace_alias)
    if os.path.exists(workspace_dir):
        host_dir = os.path.join(workspace_dir, target)
        if os.path.exists(host_dir):
            try:
                shutil.rmtree(host_dir)
                print(f"$OKBLUE[*]$RESET Deleted host: {target} from workspace: {workspace_alias} $OKBLUE[$RESET${OKGREEN}OK${RESET}$OKBLUE]$RESET")
            except Exception as e:
                print(f"$OKBLUE[*]$RESET Error deleting host: {e} $OKBLUE[$RESET${OKRED}FAILED${RESET}$OKBLUE]$RESET")
        else:
            print(f"$OKBLUE[*]$RESET Host not found: {target} in workspace: {workspace_alias} $OKBLUE[$RESET${OKRED}FAILED${RESET}$OKBLUE]$RESET")
    else:
        print(f"$OKBLUE[*]$RESET Workspace not found: {workspace_alias} $OKBLUE[$RESET${OKRED}FAILED${RESET}$OKBLUE]$RESET")

def delete_tasks_from_workspace(workspace_alias, target):
    workspace_dir = os.path.join(LOOT_DIR, workspace_alias)
    if os.path.exists(workspace_dir):
        host_dir = os.path.join(workspace_dir, target)
        if os.path.exists(host_dir):
            tasks_dir = os.path.join(host_dir, "tasks")
            if os.path.exists(tasks_dir):
                try:
                    shutil.rmtree(tasks_dir)
                    print(f"$OKBLUE[*]$RESET Deleted tasks for host: {target} from workspace: {workspace_alias} $OKBLUE[$RESET${OKGREEN}OK${RESET}$OKBLUE]$RESET")
                except Exception as e:
                    print(f"$OKBLUE[*]$RESET Error deleting tasks: {e} $OKBLUE[$RESET${OKRED}FAILED${RESET}$OKBLUE]$RESET")
            else:
                print(f"$OKBLUE[*]$RESET No tasks found for host: {target} in workspace: {workspace_alias} $OKBLUE[$RESET${OKRED}FAILED${RESET}$OKBLUE]$RESET")
        else:
            print(f"$OKBLUE[*]$RESET Host not found: {target} in workspace: {workspace_alias} $OKBLUE[$RESET${OKRED}FAILED${RESET}$OKBLUE]$RESET")
    else:
        print(f"$OKBLUE[*]$RESET Workspace not found: {workspace_alias} $OKBLUE[$RESET${OKRED}FAILED${RESET}$OKBLUE]$RESET")

def list_workspaces():
    workspace_dir = LOOT_DIR
    if os.path.exists(workspace_dir):
        workspaces = os.listdir(workspace_dir)
        if workspaces:
            print(f"$OKBLUE[*]$RESET Available workspaces:")
            for workspace in workspaces:
                print(f"  - {workspace}")
        else:
            print(f"$OKBLUE[*]$RESET No workspaces found.")
    else:
        print(f"$OKBLUE[*]$RESET Loot directory not found: {workspace_dir}")

def reimport_loot(workspace_alias):
    workspace_dir = os.path.join(LOOT_DIR, workspace_alias)
    if os.path.exists(workspace_dir):
        try:
            subprocess.run(['omg.lolz', '-w', workspace_alias, '--reimport'])
            print(f"$OKBLUE[*]$RESET Reimported loot for workspace: {workspace_alias} $OKBLUE[$RESET${OKGREEN}OK${RESET}$OKBLUE]$RESET")
        except Exception as e:
            print(f"$OKBLUE[*]$RESET Error reimporting loot: {e} $OKBLUE[$RESET${OKRED}FAILED${RESET}$OKBLUE]$RESET")
    else:
        print(f"$OKBLUE[*]$RESET Workspace not found: {workspace_alias} $OKBLUE[$RESET${OKRED}FAILED${RESET}$OKBLUE]$RESET")

def reimport_all_loot(workspace_alias):
    workspace_dir = os.path.join(LOOT_DIR, workspace_alias)
    if os.path.exists(workspace_dir):
        try:
            subprocess.run(['omg.lolz', '-w', workspace_alias, '--reimportall'])
            print(f"$OKBLUE[*]$RESET Reimported all loot for workspace: {workspace_alias} $OKBLUE[$RESET${OKGREEN}OK${RESET}$OKBLUE]$RESET")
        except Exception as e:
            print(f"$OKBLUE[*]$RESET Error reimporting all loot: {e} $OKBLUE[$RESET${OKRED}FAILED${RESET}$OKBLUE]$RESET")
    else:
        print(f"$OKBLUE[*]$RESET Workspace not found: {workspace_alias} $OKBLUE[$RESET${OKRED}FAILED${RESET}$OKBLUE]$RESET")

def reload_loot(workspace_alias):
    workspace_dir = os.path.join(LOOT_DIR, workspace_alias)
    if os.path.exists(workspace_dir):
        try:
            subprocess.run(['omg.lolz', '-w', workspace_alias, '--reload'])
            print(f"$OKBLUE[*]$RESET Reloaded loot for workspace: {workspace_alias} $OKBLUE[$RESET${OKGREEN}OK${RESET}$OKBLUE]$RESET")
        except Exception as e:
            print(f"$OKBLUE[*]$RESET Error reloading loot: {e} $OKBLUE[$RESET${OKRED}FAILED${RESET}$OKBLUE]$RESET")
    else:
        print(f"$OKBLUE[*]$RESET Workspace not found: {workspace_alias} $OKBLUE[$RESET${OKRED}FAILED${RESET}$OKBLUE]$RESET")

def export_loot(workspace_alias):
    workspace_dir = os.path.join(LOOT_DIR, workspace_alias)
    if os.path.exists(workspace_dir):
        try:
            subprocess.run(['omg.lolz', '-w', workspace_alias, '--export'])
            print(f"$OKBLUE[*]$RESET Exported loot for workspace: {workspace_alias} $OKBLUE[$RESET${OKGREEN}OK${RESET}$OKBLUE]$RESET")
        except Exception as e:
            print(f"$OKBLUE[*]$RESET Error exporting loot: {e} $OKBLUE[$RESET${OKRED}FAILED${RESET}$OKBLUE]$RESET")
    else:
        print(f"$OKBLUE[*]$RESET Workspace not found: {workspace_alias} $OKBLUE[$RESET${OKRED}FAILED${RESET}$OKBLUE]$RESET")

def schedule_scan(workspace_alias, schedule_arg):
    workspace_dir = os.path.join(LOOT_DIR, workspace_alias)
    if os.path.exists(workspace_dir):
        try:
            subprocess.run(['omg.lolz', '-w', workspace_alias, '-s', schedule_arg])
            print(f"$OKBLUE[*]$RESET Scheduled scan for workspace: {workspace_alias} $OKBLUE[$RESET${OKGREEN}OK${RESET}$OKBLUE]$RESET")
        except Exception as e:
            print(f"$OKBLUE[*]$RESET Error scheduling scan: {e} $OKBLUE[$RESET${OKRED}FAILED${RESET}$OKBLUE]$RESET")
    else:
        print(f"$OKBLUE[*]$RESET Workspace not found: {workspace_alias} $OKBLUE[$RESET${OKRED}FAILED${RESET}$OKBLUE]$RESET")

def launch_wifite2_attack():
    print("$OKBLUE[*]$RESET Launching Wifite2 attack...")
    subprocess.run(['wifite2', '--crack', '--skip-handshake'])

def run_hydra():
    print("$OKBLUE[*]$RESET Launching Hydra attack...")
    subprocess.run(['hydra'])

def run_john():
    print("$OKBLUE[*]$RESET Launching John the Ripper...")
    subprocess.run(['john'])

def help():
    print("Usage: python script.py [options]")
    print("Options:")
    print("  -t <target>    Target host or URL")
    print("  -m <mode>      Attack mode (wifite2, hydra, john, nmap, dirsearch, amass, metasploit, curl, wget, nikto, create_workspace, delete_workspace, delete_host, delete_tasks, list_workspaces, reimport_loot, reimport_all_loot, reload_loot, export_loot, schedule_scan)")
    print("  -p <port>      Port for nmap and nikto scans")
    print("  -f <file>      File for input/output")
    print("  -w <workspace> Workspace alias for workspace management")
    print("  -s <schedule>  Schedule argument for scheduling scans")
    print("  -h             Show this help message")
