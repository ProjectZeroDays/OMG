
# Username Enumeration
## List of Resources to Add:

### whatsmyname.app
### Sherlock - Maigret and Sherlock check for active sites differently than WMN
### Google Dork: inurl:$username
### UserSearch
### Mr.Holmes 
### Namechekr
### Maigret - Maigret and Sherlock check for active sites differently than WMN - (https://github.com/soxoj/maigret)
### WMN Checker [Python] - (https://github.com/WebBreacher/WhatsMyName)
### Free Resources - (https://inteltechniques.com/tools/index.html)
### Usernames can be found here - (https://inteltechniques.com/tools/Username.html)
### OSINTwolf
