import subprocess
import os

# Colors for formatting
OKBLUE = '\033[94m'
OKRED = '\033[91m'
OKGREEN = '\033[92m'
OKORANGE = '\033[93m'
RESET = '\e[0m'

# Function to run shell commands
def run_command(command):
    process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    output, error = process.communicate()
    return output.decode("utf-8"), error.decode("utf-8")

# Print colored text
def print_colored(text, color):
    print(f"{color}{text}{RESET}")

# Print colored text without newline
def print_colored_no_newline(text, color):
    print(f"{color}{text}{RESET}", end='')

# Main installation script
def install_omg_lolz():
    print_colored_no_newline("                                                  \n", OKRED)
    print_colored_no_newline("    ___  __  __  ____      _     ___   __  ____   \n", OKRED)
    print_colored_no_newline("   / _ \|  \/  |/ ___|    / /  / ,, | / / |__ /   \n", OKRED)
    print_colored_no_newline("  | | | | |\/| | |  _    / /  / / / // /   / /    \n", OKRED)
    print_colored_no_newline("  | |_| | |  | | |_| |  / /__/ /_/ // /__ / /__   \n", OKRED)
    print_colored_no_newline("   \___/|_|  |_|\____| /____/\____//____//____/   \n", OKRED)
    print_colored_no_newline("                                                  \n", OKRED)
    print_colored_no_newline("                                                  \n", OKRED)
    print_colored("               OMG.LOLz by Ezra - Project Zero              ", OKORANGE)
    print_colored("             https://github.com/ProjectZeroDays/            ", OKORANGE)
    print_colored_no_newline("                                                  \n", OKRED)

    INSTALL_DIR = "/usr/share/omg.lolz"
    LOOT_DIR = "/usr/share/omg.lolz/loot"
    PLUGINS_DIR = "/usr/share/omg.lolz/plugins"
    GO_DIR = "~/go/bin"

    print_colored_no_newline("[>] This script will install OMG.LOLz under $INSTALL_DIR. Are you sure you want to continue? (Hit Ctrl+C to exit)", OKRED)
    if input("Enter 'y' to continue: ") != "y":
        return

    # Check if running as root
    if not 'SUDO_UID' in os.environ or os.geteuid() != 0:
        print("This script must be run as root")
        return

    # Create directories and set permissions
    run_command(f"mkdir -p {INSTALL_DIR}")
    run_command(f"chmod 755 -Rf {INSTALL_DIR}")
    run_command(f"chown root {INSTALL_DIR}/omg.lolz")
    run_command(f"mkdir -p {LOOT_DIR}")
    run_command(f"mkdir {LOOT_DIR}/domains")
    run_command(f"mkdir {LOOT_DIR}/screenshots")
    run_command(f"mkdir {LOOT_DIR}/nmap")
    run_command(f"mkdir {LOOT_DIR}/reports")
    run_command(f"mkdir {LOOT_DIR}/output")
    run_command(f"mkdir {LOOT_DIR}/osint")
    
    # Additional setup commands can be added here using run_command()

# Check for Ubuntu distribution
def check_ubuntu():
    lsb_release = run_command("cat /etc/lsb-release")
    if "DISTRIB_ID=Ubuntu" in lsb_release:
        run_command("cp /root/.Xauthority /root/.Xauthority.bak")
        run_command("cp -a /run/user/1000/gdm/Xauthority /root/.Xauthority")
        run_command("cp -a /home/user/.Xauthority /root/.Xauthority")
        run_command("sudo chown root /root/.Xauthority")
        run_command("sudo snap install chromium")
        run_command("sudo ln -s /snap/bin/chromium /usr/bin/chromium")
        run_command("xhost +")
        run_command("sudo mkdir -p /run/user/0")
        run_command("sudo add-apt-repository ppa:longsleep/golang-backports")
        run_command("sudo apt update")
        run_command("sudo apt install -y golang")
        run_command("sudo apt install -y snapd")
        run_command("sudo apt install- `python omg_lolz_install_script.py`
run_command("sudo apt install -y wifite")
        run_command("sudo apt install -y python3")

# Install package dependencies
def install_dependencies():
    print_colored("[*] Installing package dependencies...", OKBLUE)
    run_command("sudo apt update")
    run_command("sudo apt install -y python3-paramiko")
    run_command("sudo apt install -y nfs-common")
    # Add more dependency installations as needed

# Install Metasploit
def install_metasploit():
    print_colored("[*] Installing Metasploit...", OKBLUE)
    run_command("curl https://raw.githubusercontent.com/rapid7/metasploit-omnibus/master/config/templates/metasploit-framework-wrappers/msfupdate.erb > /tmp/msfinstall")
    run_command("chmod 755 /tmp/msfinstall")
    run_command("/tmp/msfinstall")

    run_command("pip3 install dnspython colorama tldextract urllib3 ipaddress requests")
    run_command("curl -o- https://raw.githubusercontent.com/creationix/nvm/v0.33.8/install.sh | bash")

# Install GEM Dependencies
def install_gem_dependencies():
    print_colored("[*] Installing GEM Dependencies...", OKBLUE)
    run_command("gem install rake")
    run_command("gem install ruby-nmap")
    # Add more gem installations as needed

# Additional setup
def additional_setup():
    print_colored("[*] Setting up Ruby...", OKBLUE)
    run_command("dpkg-reconfigure ruby")
    print_colored("[*] Upgrading PIP...", OKBLUE)
    run_command("python3 -m pip install --upgrade pip")
    print_colored("[*] Cleaning up Old Extensions...", OKBLUE)
    run_command(f"rm -Rf {PLUGINS_DIR}")
    run_command(f"mkdir {PLUGINS_DIR}")

# Download and install extensions
def install_extensions():
    print_colored("[*] Downloading Extensions...", OKBLUE)
    # Add installation commands for each extension as needed

# Function to handle pip installations
def install_pip_packages():
    print_colored("[*] Installing Python Packages...", OKBLUE)
    run_command("pip3 install paramiko")
    run_command("pip3 install xdg-utils")
    run_command("pip3 install tldextract")
    # Add more pip installations as needed

# Final setup and cleanup
def final_setup():
    print_colored("[*] Finalizing Setup...", OKBLUE)
    run_command("echo 'Final setup commands here'")
    # Add final setup commands as needed

# Main function to run the script
def main():
    install_omg_lolz()
    check_ubuntu()
    install_dependencies()
    install_metasploit()
    install_gem_dependencies()
    additional_setup()
    install_pip_packages()
    install_extensions()
    final_setup()

if __name__ == "__main__":
    main()
