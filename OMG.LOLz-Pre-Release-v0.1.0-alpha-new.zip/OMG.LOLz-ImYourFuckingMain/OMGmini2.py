import platform
import os
import subprocess
import argparse
import dns.resolver
import time
import json

RESET = "\033[0m"
OKBLUE = "\033[94m"
OKGREEN = "\033[92m"
OKRED = "\033[91m"

def check_dependencies():
    dependencies = ['wifite2', 'hydra', 'john', 'nmap', 'python3-dnspython']
    missing_deps = []

    for dep in dependencies:
        try:
            subprocess.run([dep, '--version'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
        except (subprocess.CalledProcessError, FileNotFoundError):
            missing_deps.append(dep)

    if missing_deps:
        print("$OKRED[!]$RESET The following dependencies are missing:")
        for dep in missing_deps:
            print(f"  - {dep}")
        print("$OKRED[!]$RESET Please install the missing dependencies and try again.")
        sys.exit(1)

def check_wordlists():
    wordlists = ['/wordlists/usernames-full.txt', '/wordlists/web-brute-full.txt']
    for wordlist in wordlists:
        if not os.path.exists(wordlist):
            print(f"$OKRED[!]$RESET Wordlist not found: {wordlist}")
            sys.exit(1)

def wifite2_attack_summary(target, output_file):
    # ... (previous implementation)

def hydra_attack_summary(target, username_list, password_list, output_file):
    # ... (previous implementation)

def john_attack_summary(hash_file, output_file):
    # ... (previous implementation)

def nmap_scan_summary(target, output_file):
    # ... (previous implementation)

def recon_dns_summary(domain, output_file):
    # ... (previous implementation)

def write_results(results, output_file):
    # ... (previous implementation)

def load_results(output_file):
    # ... (previous implementation)

def launch_wifite2_attack(target, output_file):
    # ... (previous implementation)

def launch_hydra_attack(target, username_list, password_list, output_file):
    # ... (previous implementation)

def launch_john_attack(hash_file, output_file):
    # ... (previous implementation)

def launch_nmap_scan(target, output_file):
    # ... (previous implementation)

def launch_recon_dns(domain, output_file):
    # ... (previous implementation)

def parse_args():
    parser = argparse.ArgumentParser(description='OMG.LOLz - Project Zero')
    parser.add_argument('-t', '--target', help='Target host or URL')
    parser.add_argument('-m', '--mode', choices=['wifite2', 'hydra', 'john', 'nmap', 'recon'], help='Attack mode')
    parser.add_argument('-u', '--username-list', help='Username list for Hydra')
    parser.add_argument('-p', '--password-list', help='Password list for Hydra')
    parser.add_argument('-H', '--hash-file', help='Hash file for John the Ripper')
    parser.add_argument('-d', '--domain', help='Domain for ReconDNS')
    parser.add_argument('-o', '--output-file', default='results.json', help='Output file for results')
    return parser.parse_args()

def main():
    check_dependencies()
    check_wordlists()

    args = parse_args()
    output_file = args.output_file

    if args.mode == "wifite2":
        launch_wifite2_attack(args.target, output_file)
    elif args.mode == "hydra":
        launch_hydra_attack(args.target, args.username_list, args.password_list, output_file)
    elif args.mode == "john":
        launch_john_attack(args.hash_file, output_file)
    elif args.mode == "nmap":
        launch_nmap_scan(args.target, output_file)
    elif args.mode == "recon":
        launch_recon_dns(args.domain, output_file)
    else:
        logo()
        print_help()

def print_help():
    print("Usage: python script.py [options]")
    print("Options:")
    print("  -t, --target <target>    Target host or URL")
    print("  -m, --mode <mode>        Attack mode (wifite2, hydra, john, nmap, recon)")
    print("  -u, --username-list      Username list for Hydra")
    print("  -p, --password-list      Password list for Hydra")
    print("  -H, --hash-file          Hash file for John the Ripper")
    print("  -d, --domain             Domain for ReconDNS")
    print("  -o, --output-file        Output file for results (default: results.json)")

if __name__ == "__main__":
    main()
